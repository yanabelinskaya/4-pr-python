from bd import base
from tabulate import tabulate

db = base('Призывной отдел.db')
db.create_table('users',{'id':'INTEGER PRIMARY KEY','name':'text','surname':'text','lastname':'text','age':'INTEGER','phone_number':'text','uid':'INTEGER'})
db.create_table('otdel',{'id':'INTEGER PRIMARY KEY','user':'INTEGER','result':'text'})
users = db.read_table('users')
otdel = db.read_table('otdel')
if len(users) == 0:
    db.insert('users',{'name':'','surname':'','lastname':'','age':0,'phone_number':'','uid':111111}) 
    db.insert('users',{'name':'Иван','surname':'Иванов','lastname':'Иванович','age':18,'phone_number':'88005553535','uid':1813061}) 
    db.insert('users',{'name':'Егор','surname':'Сидоров','lastname':'Константинович','age':22,'phone_number':'88004424535','uid':2205031}) 
    db.insert('users',{'name':'Сергей','surname':'Плюшкин','lastname':'Юрьевич','age':19,'phone_number':'89367756924','uid':1917111}) 
    users = db.insert('users',{'name':'Яша','surname':'Малолеткин','lastname':'Александрович','age':14,'phone_number':'89857320758','uid':145511}) 
    db.insert('otdel',{'user':2,'result':'годен'})
    db.insert('otdel',{'user':3,'result':'годен'})


user_id = int

def auth(uid:int) -> str:
    if uid == str(111111): return 'admin'
    else: 
        global user_id
        user_id = uid
        return 'user'

def reg(name,surname,lastname,phonenumber:str,birth:str) -> str:
    try:
        for i in birth.split('.'):
            if str.isdigit(i) == False:
                print('Ошибка ввода даты')
                main()
        for i in phonenumber:
            if str.isdigit(i) == False:
                print('Ошибка ввода номера телефона')
                main()
        if name == '' or lastname == '' or surname == '' or phonenumber == '' or lastname == '':
            print("Ошибка ввода данных, повторите еще раз")
            main()
        uid = '' 
        age = 0
        for i in birth.split('.'): 
            if len(i) == 4:
                age = 2023-int(i)
                uid+=str(2023-int(i))
            else: uid+=i
        global users
        users = db.insert('users',{'name':name,'surname':surname,'lastname':lastname,'age':age,'phone_number':phonenumber,'uid':int(uid)}) 
        global user_id
        user_id = int(uid) 
        return 'user'
    except Exception as e: 
        print(f"Произошла ошибка в заполнении данных: {e}")

def create_user():
    try:
        reg(input("Введите имя пользователя: "),input("Введите фамилию пользователя: "),input("Введите отчество пользователя: "),input('Введите номер телефона пользователя: '),input('Введите дату рождения(в формате xx.xx.xxxx) пользователя: '))
        CRUD_user()
    except Exception as e: print(f'Произошла ошибка: {e}'); CRUD_user()
    except KeyboardInterrupt: exit()

def delete_user():
    try:
        global users
        id = int(input("Введите id пользователя, которого хотите удалить: "))
        if id != 1:
            users = db.delete('users',id)
        else: print("нельзя удалить админа")
        CRUD_user()
    except Exception as e: print(f'Произошла ошибка: {e}'); CRUD_user()
    except KeyboardInterrupt: exit()
    
def update_user():
    try:
        global users
        id = int(input(tabulate(users,tablefmt="github",headers='keys')+'\n\nВыберите id пользователя, которого хотите изменить данные: '))
        result = input(tabulate(users,tablefmt="github",headers='keys')+'\n\nВыберите поле пользователя, которое хотите изменить\n1. Имя\n2. Фамилия\n3. Отчество\n4. Возвраст\n5. Номер телефона\n6. UID\n')
        match(result):
            case '1':
                users = db.update('users',id,{'name':input('Введите новое значение: ')})
            case '2':
                users = db.update('users',id,{'surname':input('Введите новое значение: ')})
            case '3':
                users = db.update('users',id,{'lastname':input('Введите новое значение: ')})
            case '4':
                users = db.update('users',id,{'age':int(input('Введите новое значение: '))})
            case '5':
                users = db.update('users',id,{'phone_number':input('Введите новое значение: ')})
            case '6':
                users = db.update('users',id,{'uid':int(input('Введите новое значение: '))})
        CRUD_user()
    except Exception as e: print(f'Произошла ошибка: {e}'); CRUD_user()
    except KeyboardInterrupt: exit()

def CRUD_user():
    try:
        result = input(tabulate(users,tablefmt="github",headers='keys')+"\nВыберите действие:\n1. Добавить пользователя\n2. Удалить пользователя\n3. Изменить пользователя\n")
        if result == None:
            admin()
        elif result == "1":
            create_user()
        elif result == "2":
            delete_user()
        elif result == "3":
            update_user()
        else: admin()
    except Exception as e: print(f'Произошла ошибка: {e}'); CRUD_user()
    except KeyboardInterrupt: exit()

def update_otdel():
    try:
        global otdel
        print(tabulate(otdel,tablefmt="github",headers='keys'))
        id = int(input('Введите id строки, данные которой хотите изменить: '))
        result = input('Выберите что изменять:\n1.ID пользователя\n2.Результат годности\n')
        print(tabulate(users,tablefmt="github",headers='keys'))
        if result == '1':
            new_id = int(input('Новый id пользователя: '))
            if new_id in [i['user'] for i in otdel]:
                print('Ошибка - такой пользователь уже использован!')
            else:
                otdel = db.update('otdel',id,{'user': new_id})
        elif result == '2':
            otdel = db.update('otdel',id,{'result': input('Новый результат: ')})
        else: CRUD_otdel()
        CRUD_otdel()
    except Exception as e: print(f'Произошла ошибка: {e}'); CRUD_otdel()
    except KeyboardInterrupt: exit()

def create_otdel():
    try:
        global otdel
        print(tabulate(users,tablefmt="github",headers='keys'))
        id = int(input('ID пользователя: '))
        if id in [i['user'] for i in otdel]:
            print('Ошибка - такой пользователь уже использован!')
        else:
            otdel = db.insert('otdel',{'user':id,'result':input('Результат годности: ')})
        CRUD_otdel()
    except Exception as e: print(f'Произошла ошибка: {e}'); CRUD_otdel()
    except KeyboardInterrupt: exit()

def delete_otdel():
    try:
        global otdel
        print(tabulate(otdel,tablefmt="github",headers='keys'))
        otdel = db.delete('otdel',int(input("Введите id строчки, которого хотите удалить: ")))
        CRUD_otdel()
    except Exception as e: print(f'Произошла ошибка: {e}'); CRUD_otdel()
    except KeyboardInterrupt: exit()

        
def CRUD_otdel():
    try:
        result = input(tabulate(otdel,tablefmt="github", headers='keys')+"\n1. Добавить призыв\n2. Удалить призыв\n3. Изменить призыв\n")
        if result == None:
            admin()
        elif result == "1":
            create_otdel()
        elif result == "2":
            delete_otdel()
        elif result == "3":
            update_otdel()
        else:
            main()
    except Exception as e: print(f'Произошла ошибка: {e}'); main()
    except KeyboardInterrupt: exit()

def get_user(uid:int = 0, id:int = 0):
    if uid != 0:
        for i in users:
            if i['uid'] == uid:
                return i
    if id != 0:
        for i in users:
            if i['id'] == id:
                return i

def user():
    global otdel
    try:
        result = input('Выберите действие:\n1. Посмотреть призывы\n2. Начать косить\n3. Призваться\n')
        match(result):
            case '1':
                prizvan = False
                for i in otdel:
                    if str(get_user(id=i['user'])['uid']) == user_id:
                        print(tabulate([i],tablefmt="github", headers='keys'))
                        prizvan = True
                        break
                if prizvan != True:
                    print('Пока живи')
                user()
            case '2':
                print('Чертила, че ты косишь!')
                user()
            case '3':
                skip = False
                for i in otdel:
                    if str(get_user(id=i['user'])['uid']) == str(user_id):
                        print('Мы Вас уже давно ждем!')
                        skip = True
                        break
                if skip != True:
                    otdel = db.insert('otdel',{'user':[i['id'] for i in users if str(i['uid']) == str(user_id)][0],'result':'годен'})
                    print('Уже завтра ждем на фронте')
                user()
            case _:
                main()
    except Exception as e: print(f'Произошла ошибка: {e}'); user()
    except KeyboardInterrupt: exit()

def admin():
    try:
        result = input('Выберите действие\n1. Посмотреть всех пользователей\n2. Призвать пользователя\n')
        match(result):
            case '1':
                CRUD_user()
            case '2':
                CRUD_otdel()
            case _:
                main()
    except Exception as e: print(f'Произошла ошибка: {e}'); main()
    except KeyboardInterrupt: exit()

def menu(role:str):
    if role == 'admin':
        admin()
    elif role == 'user':
        user()

            
def main():
    try:
        result = input('Выберите действие:\n1. Авторизация\n2. Регистрация\n')
        match(result):
            case '1':
                role = auth(input('Введите ваш uid: ')) 
                if role != None: menu(role)
                else: main()
            case '2':
                role = reg(input("Введите Ваше имя: "),input("Введите Вашу фамилию: "),input("Введите Ваше отчество: "),input('Введите Ваш номер телефона: '),input('Введите дату рождения(в формате xx.xx.xxxx): '))
                menu(role)
    except Exception as e: print(f'Произошла ошибка: {e}'); main()
    except KeyboardInterrupt: exit()

if __name__ == '__main__':
    main()